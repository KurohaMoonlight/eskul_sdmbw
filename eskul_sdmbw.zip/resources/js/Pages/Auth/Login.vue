<template>
    <div>
        <loginForm/>
    </div>
</template>

<script setup>
    import loginForm from '../../Components/loginForm.vue';

</script>

<style scoped>
    
</style>